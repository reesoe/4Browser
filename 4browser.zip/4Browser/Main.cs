﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4Browser
{
    public partial class Main : Form
    {
        FormWindowState normalWindowState;
        FormBorderStyle normalBorderStyle;
        Point normalLocation;

        public Main()
        {
            normalLocation = this.Location;
            normalWindowState = this.WindowState;
            normalBorderStyle = this.FormBorderStyle;
            InitializeComponent();
        }

      
        private void LoadSettings()
        {
            MessageBox.Show("indlæsser instillinger.... Test metode","Not Implemented!",MessageBoxButtons.OK, MessageBoxIcon.Exclamation ) ;
        }

   
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.F11:
                    SwichKioskMode();
                    return true;
                case Keys.F12:
                    using (Settings setting = new Settings())
                    {
                        if (setting.ShowDialog() == DialogResult.OK)                        
                            LoadSettings();                        
                    }
                    return true;
                default:
                    // Call the base class
                    return base.ProcessCmdKey(ref msg, keyData);
            }
        }

        private void SwichKioskMode()
        {
            if (!TopMost) // TopMost = Kiosk mode
            {
                normalLocation = Location;
                normalWindowState = WindowState;
                normalBorderStyle = FormBorderStyle;
                TopMost = true;
                FormBorderStyle = FormBorderStyle.None;
                WindowState = FormWindowState.Maximized;
                WinApi.SetWinFullScreen(Handle);
            }
            else 
            {
                TopMost = false;
                FormBorderStyle = normalBorderStyle;
                WindowState = normalWindowState;
                Location = normalLocation ;
            }
        }
    }
}
